/* GET about view */
const about = (req,res) =>{
    res.render('about',{title:'Tralvr Getaways'})
}

module.exports={
    about
}