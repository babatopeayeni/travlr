/* GET contact view */
const contact = (req,res) =>{
    res.render('contact',{title:'Tralvr Getaways'})
}

module.exports={
    contact
}